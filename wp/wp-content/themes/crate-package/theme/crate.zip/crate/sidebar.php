<?php
/**
 * The sidebar containing the default sidebar
 *
 *
 * @package WordPress
 * @subpackage Crate
 * @author ThemeBeans
 * @since Crate 1.0
 */
 
 dynamic_sidebar(); // DISPLAY THE SIDEBAR